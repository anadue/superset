import { Point } from './types';
export default function computeBoundsFromPoints(points: Point[]): number[][];
//# sourceMappingURL=computeBoundsFromPoints.d.ts.map