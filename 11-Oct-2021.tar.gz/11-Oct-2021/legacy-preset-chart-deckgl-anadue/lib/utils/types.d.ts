export declare type Range = [number, number];
export declare type Point = [number, number];
//# sourceMappingURL=types.d.ts.map