export {default as GoogleMapsOverlay} from './google-maps-overlay';
