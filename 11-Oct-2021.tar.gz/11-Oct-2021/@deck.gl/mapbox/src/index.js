export {default as MapboxLayer} from './mapbox-layer';
