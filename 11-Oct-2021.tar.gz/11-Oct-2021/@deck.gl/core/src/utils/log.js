import {Log} from 'probe.gl';

export default new Log({id: 'deck'}).enable();
